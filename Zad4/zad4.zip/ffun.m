function [ffun_value] = ffun(fenotyp)

% Przykladowa funkcja przystosowania
x1 = fenotyp(1,:);
x2 = fenotyp(2,:);
if x1<-5 || x1>5 || isnan(x1)
    y=-20;
elseif x2<-5 || x2>5 || isnan(x2)
    y=-20;
else
y=-20*exp(-0.2*sqrt(0.5*(x1.^2+x2.^2)))-exp(0.5*(cos(2*pi*x1)+cos(2*pi*x2)))+20+exp(1);
y = -y;
y = real(y);
end

ffun_value = y;

ffun_value = y;

end