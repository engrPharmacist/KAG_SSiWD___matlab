function [pop]=inicjalizacja(param)

popsize = param.K;       % liczba chromosomow K
chromlength = param.L;   % dlugosc wektora binarnego L
fenotyp_max = param.fenotyp_max;   % minmalna wartosc fenotupu, zdeokdowanego wektora binarnego
fenotyp_min = param.fenotyp_min;   % maksymalna wartosc fenotupu, zdeokdowanego wektora binarnego

pop = round(rand(popsize, chromlength+3));
for i = 1:popsize
    val1 = fenotyp_min + (fenotyp_max - fenotyp_min).*rand(1,1);
    val2 = fenotyp_min + (fenotyp_max - fenotyp_min).*rand(1,1);
    
    pop(i, 1:chromlength/2) = dec2bin(typecast(single(val1), 'uint32'), chromlength / 2) - '0';
    pop(i, chromlength/2+1:chromlength) = dec2bin(typecast(single(val2), 'uint32'), chromlength / 2) - '0';
end

% 3) na podstawie kodowanie binarnego liczby zmiennoprzecinkowej pojedynczej precyzji (chromlength = param.L = 32)
pop(:, chromlength+1) = typecast(uint32(bin2dec(num2str(pop(:,1:chromlength/2)))),'single'); 
pop(:, chromlength+2) = typecast(uint32(bin2dec(num2str(pop(:,chromlength/2+1:chromlength)))),'single'); 

%wartosc funkcji przystosowania -> ffun() to przykladowa funkcja w m-pliku
pop(:, chromlength+3) = ffun([pop(:, chromlength+1); pop(:, chromlength+2)])

end